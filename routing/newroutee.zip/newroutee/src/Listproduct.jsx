import React from "react";
export default function Listproduct() {
  return <h2>Product Listing Page</h2>;
}
