import React from "react";
export default function Contactus() {
  return <h2>Contact Us Page</h2>;
}
