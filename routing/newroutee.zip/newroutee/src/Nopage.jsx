import React from "react";
export default function Nopage() {
  return <h2 style={{ color: "red" }}>404 Page Not Found</h2>;
}
